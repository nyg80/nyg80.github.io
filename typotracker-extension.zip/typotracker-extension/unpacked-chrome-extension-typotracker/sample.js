
/*pieces of info to be stored:

-url of page
-screenshot of page
-datetime
-domain of URL
-typo text (whatever was selected)
-

*/

var url;
var selection;

var sUrl; //screenshot URL

var id = 100;

function setScreenshotUrl(url) {
  document.getElementById('target').src = url;
}

// The onClicked callback function.
function onClickHandler(info, tab) {

	url = tab.url;
	selection = info.selectionText;
	
	chrome.tabs.captureVisibleTab(function(screenshotUrl) {

    	sUrl = screenshotUrl;
    	
    	typoPopup(info, tab);
  	});

};


//create the popup window
function typoPopup(info, tab)	{

	chrome.tabs.create({
		url: chrome.extension.getURL('dialog.html'),
		active: false
	}, function(tab)	{
		chrome.windows.create({
			tabId: tab.id,
			type: 'popup',
			focused: true,
			width: 500,
			height: 300
		});
	});
}

chrome.contextMenus.onClicked.addListener(onClickHandler);

// Set up context menu tree at install time
chrome.runtime.onInstalled.addListener(function() {

	var context = "selection";
	var title = "Correct Typo";

	var id = chrome.contextMenus.create({"title": title, "contexts":[context],
                                         "id": "context" + context});

});

