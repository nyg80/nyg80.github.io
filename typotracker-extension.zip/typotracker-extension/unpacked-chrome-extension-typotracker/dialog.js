
var bg = chrome.extension.getBackgroundPage();

var url = bg.url;
var selection = bg.selection;
var sUrl = bg.sUrl; //screenshot URL

document.getElementById('typo_text').value = selection;

document.getElementById('screenshot').value = sUrl;

document.getElementById('pageUrl').value = url;

