<?php

ini_set('display_errors', 'On');

$link = mysqli_connect("localhost", "root", "root") or die(mysqli_error());
mysqli_select_db($link,"typotracker") or die(mysqli_error());
?>
