<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>List of Typos I've found | Proofreading Service</title>
</head>

<body style="padding-right:150px;padding-left:150px;background-color:LightGray;">
<div style="background-color:white;padding:30px;">
<a href="http://127.0.0.1/typo/index.php"><img src="./ribbon-2.png" style="position:fixed; top:-25;left:-25;border:0;"></a>


<table border="1">
<tbody>
<tr><th>Date</th><th>Website (click to view page now)</th><th>Typo (click to view typo screenshot)</th><th>Correction</th></tr>

<?php 

include_once('conn.php');

//select statement... no pagination.  Add some in if the table gets too large
$sql = "SELECT * FROM typo;";
$result = mysqli_query($link,$sql);
while($row = mysqli_fetch_assoc($result))	{
	echo '<tr><td title="'.$row['datetime'].'">'.substr($row['datetime'],0,strpos($row['datetime'],' ')).'</td><td><a href="'.$row['url'].'" title="click to visit '.$row['url'].'" target="_blank" rel="nofollow">'.$row['domain'].'</a> </td><td><a href="http://127.0.0.1/typo/screenshot.php?id='.$row['id'].'" title="click to view screenshot">'.$row['typo_text'].'</a></td><td>'.$row['corrected_text'].'</td></tr>';
}

?>

</tbody></table><br>
<br>
<br>
</div>

</body></html>

