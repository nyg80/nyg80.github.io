<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Proofreading Service</title>
</head>

<body style='background-color:LightGray;font-family:Arial, Helvetica, sans-serif;'>
<div style='width:800px; margin-left:auto; margin-right:auto;background-color:white;padding:30px;'>

<h2>Proofreading Service</h2>
<p>A website loses credibility in the eyes of its viewers as soon as they see a typo(<a href='' target='_blank' >source</a>).  To be sure that you maintain a good perception with your website visitors, hire me to proofread your website, articles, or blog posts.</p>
<h3>How it Works</h3>
<p>Send me an email at <a href='mailto:ac.editservices@gmail.com' >ac.editservices@gmail.com</a> with your piece attached, and I will reply with the corrected version and your invoice.  I charge $15 per thousand words, rate negotiable for 1 person businesses.</p>
<h3>Past Work</h3>
<p><a href='./view.php' >Click here to see errors that I've found in publications such as New York Magazine, the Washington Post, The Guardian, and more.</a></p>

<br>
</div>

</body></html>

