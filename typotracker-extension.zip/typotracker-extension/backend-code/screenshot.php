<?php
include_once('conn.php');

$sql = "SELECT * FROM typo WHERE id = ".$_GET['id']." LIMIT 1;";
$result = mysqli_query($link,$sql);
while($row = mysqli_fetch_assoc($result))	{
	//var_dump($row);
	?>

<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Screenshot of Typo from <?php echo $row['domain'];  ?> | Proofreading Service</title>
</head>


<body style="padding-left:150px;padding-right:150px;background-color:LightGray;">
<div style='background-color:white;padding:30px;'>
<a href="http://127.0.0.1/typo/index.php"><img src="./ribbon-2.png" style="position:fixed; top:-25;left:-25;border:0;"></a>

Below, you can see a screenshot of the page<br /> <a href='<?php echo $row['url'];?>' target='_blank' rel='nofollow' ><?php echo $row['url']."</a><br /> taken on ".$row['datetime']." <br />where <strong>".$row['typo_text']."</strong> should read <strong>".$row['corrected_text'];?></strong>
<br />
<img src=' <?php echo $row['screenshot']; } ?>' />

<br>
<br>
<br>
<br>

</div>
</body></html>

