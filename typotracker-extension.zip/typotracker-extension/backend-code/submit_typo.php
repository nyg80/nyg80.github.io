<html>
<head>
<title>Typo Submission Results</title>
</head>
<body>

<?php
include_once('conn.php');

//print_r($_POST);
if ($_POST)	{

	echo "<br />\n";

	$url = mysqli_real_escape_string($link,$_POST['url']);
	$domain = mysqli_real_escape_string($link,str_ireplace('www.', '', parse_url($url, PHP_URL_HOST)));
	$mysqldate = date( 'Y-m-d H:i:s');
	$typo_text = mysqli_real_escape_string($link,$_POST['typo_text']);
	$corrected_text = mysqli_real_escape_string($link,$_POST['corrected_text']);
	$screenshot = mysqli_real_escape_string($link,$_POST['screenshot']);

	$query = "INSERT INTO `typo` (`url`, `domain`, `datetime`, `typo_text`,`corrected_text`,`screenshot`) VALUES ('$url', '$domain','$mysqldate','$typo_text','$corrected_text','$screenshot')";

	if (mysqli_query($link, $query)) {
		echo "Successfully inserted " . mysqli_affected_rows($link) . " row<br />";
	} else {
	echo "Error occurred: " . mysqli_error($link);
	}

	echo "<br /><a href='screenshot.php?id=".mysqli_insert_id($link)."' target='_blank' onClick='javascript:window.close();' >Click to view the Screenshot</a><br />";
	echo "<a href='view.php' target='_blank' onClick='javascript:window.close();' >Click to view all Typos</a><br />";
	echo "<a href='javascript:window.close();'>Close this Window</a>";
}

echo "<br />";
?>
</body>
</html>

