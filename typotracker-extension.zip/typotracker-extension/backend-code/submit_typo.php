<html>
<head>
<title>Typo Submission Results</title>
</head>
<body>

<?php
include_once('conn.php');

//print_r($_POST);
if ($_POST)	{

	echo "<br />\n";

	$url = $_POST['url'];
	$domain = str_ireplace('www.', '', parse_url($url, PHP_URL_HOST));
	$mysqldate = date( 'Y-m-d H:i:s');
	$typo_text = $_POST['typo_text'];
	$corrected_text = $_POST['corrected_text'];
	$screenshot = $_POST['screenshot'];

	$query = "INSERT INTO `typo` (`url`, `domain`, `datetime`, `typo_text`,`corrected_text`,`screenshot`) VALUES ('$url', '$domain','$mysqldate','$typo_text','$corrected_text','$screenshot')";

	if (mysqli_query($link, $query)) {
		echo "Successfully inserted " . mysqli_affected_rows($link) . " row<br />";
	} else {
	echo "Error occurred: " . mysqli_error($link);
	}

	echo "<br /><a href='screenshot.php?id=".mysqli_insert_id($link)."' target='_blank' onClick='javascript:window.close();' >Click to view the Screenshot</a><br />";
	echo "<a href='view.php' target='_blank' onClick='javascript:window.close();' >Click to view all Typos</a><br />";
	echo "<a href='javascript:window.close();'>Close this Window</a>";
}

echo "<br />";
?>
</body>
</html>

